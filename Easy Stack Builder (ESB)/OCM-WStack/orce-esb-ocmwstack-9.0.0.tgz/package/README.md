# OCM-W-Stack Node

This package deploys the OCM W-Stack through a Node-RED node, Bash orchestration, and Helm charts.

## Inputs

The node editor is organized into three tabs:
- Instance Info
- Kubernetes & Domain
- Keycloak & Credentials

Required inputs:
- instance name / namespace
- base domain
- notification email
- kubeconfig content
- TLS private key
- TLS certificate

## Deployment flow

`deploy.sh` now performs:
- preflight validation through `preflight.sh`
- namespace creation, TLS secret creation, ResourceQuota, LimitRange, and namespace RBAC bootstrap
- Helm-based OCM stack deployment
- dedicated Keycloak realm and confidential client provisioning through `kcadm.sh`
- secure persistence of generated Keycloak client credentials in Kubernetes Secrets
- structured `EVENT_JSON=` progress lines and a deterministic `OUTPUT_JSON=` result line
- rollback via `uninstall.sh` when a deployment phase fails
- smoke checks for ingress and Keycloak reachability

## Output contract

Successful runs emit the following JSON payload:

```json
{
  "ocmUrl": "https://cloud-wallet.<domain>",
  "keycloakUrl": "https://auth-cloud-wallet.<domain>",
  "clientSecret": "<secret>",
  "externalIp": "<load-balancer-ip-or-host>",
  "status": "Implemented"
}
```

## Validation and test helpers

Run the static validation suite from the package root:

```bash
./test/static-validate.sh
```

The suite checks:
- Bash syntax for deploy, uninstall, and preflight scripts
- output schema presence and required keys
- deterministic `EVENT_JSON=` and `OUTPUT_JSON=` support
- optional Helm template rendering for the Keycloak and well-known ingress charts
