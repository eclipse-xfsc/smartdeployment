# TSA Stack Node-RED module

This module deploys a lean TSA stack into its own Kubernetes namespace while reusing shared OCMW services from another namespace over in-cluster DNS.

## What changed

Compared with the first TSA module draft, this version does **not** deploy duplicate copies of services that are typically already present in the OCMW stack.

It reuses these services from the supplied **OCMW namespace**:

- Keycloak
- signer
- NATS
- DID resolver / universal resolver

It keeps these TSA-specific parts local to the TSA namespace:

- policy
- task
- cache
- infohub
- MongoDB
- Redis
- optional legacy login
- optional Mailhog for the login flow

## Public exposure

The deployer keeps most services internal-only and exposes a single host:

- `https://<tsa-namespace>.<base-domain>/infohub`
- `https://<tsa-namespace>.<base-domain>/login` (when enabled)

Everything else is wired through Kubernetes DNS such as:

- `http://keycloak.<ocmw-namespace>.svc.cluster.local:8080`
- `http://signer.<ocmw-namespace>.svc.cluster.local:8080`
- `nats.<ocmw-namespace>.svc.cluster.local:4222`

## Inputs

- **TSA namespace**: the namespace to create for the TSA-specific services.
- **OCMW namespace**: the namespace where the shared OCMW services already run.
- **Base domain**: used to build the single TSA host `<tsa-namespace>.<base-domain>`.
- **TLS key/cert**: certificate material used for the public TSA ingress.
- **Registry image prefix**: image prefix such as `ghcr.io/myorg/tsa`.
- **Registry credentials**: credentials used for `docker login` and the Kubernetes pull secret.
- **OCM address**: optional override for the legacy TSA login flow.

## Host prerequisites

The machine running Node-RED must have these tools on `PATH`:

- `kubectl`
- `helm`
- `docker`
- `git`
- `curl`
- `openssl`

## Notes

- The module only deletes the TSA namespace on uninstall. It does **not** touch the shared OCMW namespace.
- The deployer persists the TSA MongoDB and Keycloak client secrets so repeated runs stay idempotent.
- The login flow defaults the OCM address to `https://cloud-wallet.<base-domain>` when no explicit value is given.
